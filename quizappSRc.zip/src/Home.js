import React, { Component } from 'react';
import fire from './config/Fire';
import Navbar from './includes/Navbar'
class Home extends Component {
    constructor(props) {
        super(props);
        this.logout = this.logout.bind(this);
    }


    logout() {
        fire.auth().signOut();
      
    };
  render(e) {
    return (
        <div>
        <Navbar />
            <div className="container navbar nav  bg-light mt-4">
            
        <h1 className="text-warning">Welcome, {fire.auth().currentUser.displayName}  <span className="fa fa-heart text-danger"></span></h1>
     <button className="btn btn-danger float-right mb-4" onClick={this.logout}>Logout Account</button>
            </div>
            </div>
        );

    }

}

export default Home;

