import React from 'react';


class Question extends React.Component {
  handleChange(e) {
    const {setCurrent, setScore, question} = this.props;
    e.preventDefault();
    const selected = e.target.value;
    setCurrent(this.props.current + 1);
    if (selected === question.correct) {
      setScore(this.props.score + 1);
    }
  }
  render() {
    const {question} = this.props;
    return (
      <div className="container well">
     
  
        <h2 className="text-center text-info"> {question.text}</h2>
       <hr />
        <ul className="list-group">
          {
            question.choices.map(choice => {
              return (
                <div><li className="list-group-item " key={choice.id}>{choice.id}
                <input onChange={this.handleChange.bind(this)} type="radio" name={question.id} value={choice.id}/> {choice.text}
              </li></div>
              );
            })
          }
        </ul>
      </div>
    );
  }
}

export default Question;
