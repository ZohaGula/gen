import React from 'react';
import logo from './download.png'
class BoxScore extends React.Component {
  render() {
    return(
      <div  className="container text-center header">
       <h2>  <img src={logo} width="200" height="150" className="img-responsive" /> 
       <span className=" score "> Question {this.props.current} out of {this.props.questions.length}</span></h2>
      </div>
    );
  }
}

export default BoxScore;
