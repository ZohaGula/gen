import React, { Component } from "react";

import fire from "./config/Fire";
import ReactDOM from 'react-dom';

class Login extends Component {
  constructor(props) {
    super(props);
    this.login = this.login.bind(this);
    this.handleChange = this.handleChange.bind(this);
    this.signup = this.signup.bind(this);
    this.state = {
      email: "",
      password: ""
    };
    
  }

  handleChange(e) {
    this.setState({ [e.target.name]: e.target.value });
  }

  login(e) {
    e.preventDefault();
    const fullName = this.state;
    fire
      .auth()
      .signInWithEmailAndPassword(this.state.email, this.state.password)
      .then(user => {
        user.updateProfile({
          displayName: fullName
      })
    })
      .catch(error => {
        var errorCode = error.code;
        var errorMessage = error.message;

        if (error) {
          alert(error);
        } else {
          alert(errorMessage);
        }
      });
    
  }
  signup(e) {
    e.preventDefault();
    const {fullName, email1, password1} = this.state;
    fire
      .auth()
      .createUserWithEmailAndPassword(email1, password1)
      .then(user => {
        user.updateProfile({
          displayName: fullName
      }).then(function() {
          // Update successful.
      }, function(error) {
         alert("OoOps..!, " , error);
              
  },
      )})
      .then(user => {
        console.log(user);
      })
      .catch(error => {
        alert(error.message);
      });
     
  }
  forgot() {
    //var auth =
    var emailAddress = "zohagul007@gmail.com";
    fire.auth().sendPasswordResetEmail(emailAddress)
      .then(function() {
        alert("Email sent");
      })
      .catch(function(error) {
        console.log("Email failed",error);
      });
  }

  resetpass() {
    document.getElementById("resetpas").style.display = "block";
    document.getElementById("reset").style.display = "block";
    document.getElementById("cancel").style.display = "block";
  }
  cancel() {
    document.getElementById("resetpas").style.display = "none";
    document.getElementById("reset").style.display = "none";
    document.getElementById("cancel").style.display = "none";
  }
  render() {
    return (
      <div className="container wrapper fadeInDown">
        <div id="formContent">
          <div className="fadeIn first  mb-2">
            <img
              src="http://www.transparentpng.com/thumb/flight-attendant/flight-attendant-user-icons-png-6.png"
              id="icon"
              alt="User Icon"
            />
          </div>
          <form>
            <div className="container mb-3">
              <input
                className="fadeIn second form-control mb-2"
                value={this.state.email}
                onChange={this.handleChange}
                type="email"
                name="email"
                id="exampleInputEmail1"
                placeholder="Enter email"
              />
              <input
                value={this.state.password}
                onChange={this.handleChange}
                type="password"
                name="password"
                className="form-control"
                id="exampleInputPassword"
                placeholder="Enter Passsword"
              />
            </div>
            <button
              type="submit"
              onClick={this.login}
              className="fadeIn fourth btn btn-success mb-2"
            >
              Login here
            </button>
            <div className="container mb-3">
              <input
                value={this.state.fullName}
                onChange={this.handleChange}
                type="text"
                name="fullName"
                className="form-control  mb-2"
                id="exampleInputFullname"
                placeholder="Enter full name"
              />
              <input
                className="fadeIn second form-control mb-2"
                value={this.state.email1}
                onChange={this.handleChange}
                type="email"
                name="email1"
                id="exampleInputEmail1"
                placeholder="Enter email"
              />
              <input
                value={this.state.password1}
                onChange={this.handleChange}
                type="password"
                name="password1"
                className="form-control"
                id="exampleInputPassword1"
                placeholder="Enter Passsword"
              />
            </div>

            <button
              type="submit"
              onClick={this.signup}
              className="fadeIn fourth btn btn-info mb-2"
              style={{ marginLeft: "10px" }}
            >
              Create New Account
            </button>
          </form>

          <div id="formFooter">
            <a
              className="underlineHover"
              id="resetpass"
              onClick={this.resetpass.bind()}
            >
              Forgot Password?
            </a>

            <input type="email"
              placeholder="Reset your password"
              className="form-control  mb-3"
              style={{ display: "none" }}
              id="resetpas" 
            />
            <div className="col-md-12">
              <a
                className="underlineHover btn btn-warning"
                id="reset"
                onClick={this.forgot.bind()}
                style={{ display: "none", textDecoration: "none " }}
              ref='email'>
                Reset
              </a>
              <a
                className="underlineHover btn btn-danger"
                id="cancel"
                onClick={this.cancel.bind()}
                style={{ display: "none" }}
              >
                Cancel
              </a>
            </div>
          </div>
        </div>
      </div>
    );
  }
}
export default Login;
